﻿namespace Dreambit;

public static class DrawLayers
{
    public const int DefaultLayer = 0;
    public const int LightLayer = -1000;
}