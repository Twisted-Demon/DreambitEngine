﻿namespace Dreambit;

public static class Fonts
{
    public const string Default = "Fonts/monogram-font";
}