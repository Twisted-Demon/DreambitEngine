﻿namespace Dreambit;

public enum CameraFollowBehavior
{
    Direct,
    Lerp
}