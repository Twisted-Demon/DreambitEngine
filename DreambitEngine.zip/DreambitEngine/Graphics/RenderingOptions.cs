﻿using Microsoft.Xna.Framework.Graphics;

namespace Dreambit;

public static class RenderingOptions
{
    public static BlendState BlendState = BlendState.AlphaBlend;
    public static SamplerState SamplerState = SamplerState.AnisotropicClamp;
}