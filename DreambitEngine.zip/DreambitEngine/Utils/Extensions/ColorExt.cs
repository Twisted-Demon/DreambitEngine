﻿using Microsoft.Xna.Framework;

namespace Dreambit;

public static class ColorExt
{

}