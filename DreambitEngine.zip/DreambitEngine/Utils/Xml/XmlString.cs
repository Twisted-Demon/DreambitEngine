﻿namespace Dreambit.Xml;

public class XmlString
{
    public string Value { get; set; } = string.Empty;
}