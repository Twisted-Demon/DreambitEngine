﻿namespace Dreambit;

public enum LogLevel
{
    Trace = 0,
    Debug = 1,
    Info = 3,
    Warn = 4,
    Error = 5,
    None = 6
}